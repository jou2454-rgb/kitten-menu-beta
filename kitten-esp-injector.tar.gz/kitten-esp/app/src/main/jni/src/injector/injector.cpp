// ptrace-based arm64 dlopen injector
// usage: injector <pid> </path/to/lib.so>
// requires root (run via su)

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cerrno>
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <dlfcn.h>
#include <linux/elf.h>

struct arm64_regs {
    uint64_t regs[31];
    uint64_t sp;
    uint64_t pc;
    uint64_t pstate;
};

static bool get_regs(pid_t pid, arm64_regs* out) {
    struct iovec iov = { out, sizeof(*out) };
    return ptrace(PTRACE_GETREGSET, pid, (void*)NT_PRSTATUS, &iov) == 0;
}

static bool set_regs(pid_t pid, const arm64_regs* r) {
    struct iovec iov = { const_cast<arm64_regs*>(r), sizeof(*r) };
    return ptrace(PTRACE_SETREGSET, pid, (void*)NT_PRSTATUS, &iov) == 0;
}

// find base address of a library in /proc/<pid>/maps
static uintptr_t find_lib_base(pid_t pid, const char* lib) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* f = fopen(path, "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        if (!strstr(line, lib)) continue;
        if (!strstr(line, "r-xp") && !strstr(line, "r--p")) continue;
        unsigned long long addr = 0;
        if (sscanf(line, "%llx-", &addr) == 1) {
            base = static_cast<uintptr_t>(addr);
            break;
        }
    }
    fclose(f);
    return base;
}

// compute remote address of a local function, given matching lib loaded in both processes
static uintptr_t remote_func(pid_t pid, const char* lib, void* local_func) {
    uintptr_t local_base = find_lib_base(getpid(), lib);
    uintptr_t remote_base = find_lib_base(pid, lib);
    if (!local_base || !remote_base) return 0;
    return remote_base + (reinterpret_cast<uintptr_t>(local_func) - local_base);
}

// write data to remote process memory via PTRACE_POKEDATA
static bool poke_data(pid_t pid, uintptr_t addr, const void* data, size_t len) {
    const uint64_t* src = reinterpret_cast<const uint64_t*>(data);
    size_t words = (len + 7) / 8;
    for (size_t i = 0; i < words; ++i) {
        uint64_t word = 0;
        size_t remaining = len - i * 8;
        memcpy(&word, reinterpret_cast<const char*>(src) + i * 8,
               remaining < 8 ? remaining : 8);
        if (ptrace(PTRACE_POKEDATA, pid, (void*)(addr + i * 8), (void*)word) != 0) {
            fprintf(stderr, "POKEDATA failed at %p+%zu: %s\n",
                    (void*)addr, i * 8, strerror(errno));
            return false;
        }
    }
    return true;
}

// call a remote function: sets up regs, runs until SIGSEGV (ret to 0), reads x0
static uint64_t remote_call(pid_t pid, uintptr_t func,
                            uint64_t a0 = 0, uint64_t a1 = 0,
                            uint64_t a2 = 0, uint64_t a3 = 0) {
    arm64_regs regs{};
    if (!get_regs(pid, &regs)) {
        fprintf(stderr, "get_regs failed: %s\n", strerror(errno));
        return 0;
    }
    arm64_regs saved = regs;

    regs.regs[0] = a0;
    regs.regs[1] = a1;
    regs.regs[2] = a2;
    regs.regs[3] = a3;
    regs.pc = func;
    regs.regs[30] = 0; // LR = 0 → SIGSEGV on return

    if (!set_regs(pid, &regs)) {
        fprintf(stderr, "set_regs failed: %s\n", strerror(errno));
        set_regs(pid, &saved);
        return 0;
    }

    ptrace(PTRACE_CONT, pid, nullptr, nullptr);
    int status = 0;
    waitpid(pid, &status, 0);

    // process should have stopped with SIGSEGV (returned to address 0)
    // or SIGTRAP. either way, read result from x0.
    uint64_t result = 0;
    arm64_regs after{};
    if (get_regs(pid, &after)) {
        result = after.regs[0];
    }

    // restore original state
    set_regs(pid, &saved);
    return result;
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s <pid> <path_to_so>\n", argv[0]);
        return 1;
    }
    pid_t pid = atoi(argv[1]);
    const char* so_path = argv[2];

    if (access(so_path, R_OK) != 0) {
        fprintf(stderr, "cannot access %s: %s\n", so_path, strerror(errno));
        return 1;
    }

    printf("[*] attaching to pid %d\n", pid);
    if (ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) != 0) {
        fprintf(stderr, "PTRACE_ATTACH failed: %s\n", strerror(errno));
        fprintf(stderr, "    try: setenforce 0\n");
        return 1;
    }

    int status = 0;
    waitpid(pid, &status, 0);
    if (!WIFSTOPPED(status)) {
        fprintf(stderr, "process did not stop after attach\n");
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return 1;
    }
    printf("[+] attached, signal=%d\n", WSTOPSIG(status));

    // resolve remote mmap and dlopen
    uintptr_t r_mmap = remote_func(pid, "libc.so", reinterpret_cast<void*>(&mmap));
    if (!r_mmap) {
        fprintf(stderr, "failed to resolve remote mmap\n");
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return 1;
    }
    printf("[+] remote mmap: %p\n", (void*)r_mmap);

    uintptr_t r_dlopen = remote_func(pid, "libdl.so", reinterpret_cast<void*>(&dlopen));
    if (!r_dlopen) {
        fprintf(stderr, "failed to resolve remote dlopen\n");
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return 1;
    }
    printf("[+] remote dlopen: %p\n", (void*)r_dlopen);

    // allocate memory in target for the .so path string
    size_t path_len = strlen(so_path) + 1;
    size_t alloc_size = (path_len + 0xFFF) & ~0xFFF; // page-align

    printf("[*] allocating %zu bytes in target\n", alloc_size);
    uint64_t remote_mem = remote_call(pid, r_mmap,
        0,                                  // addr
        alloc_size,                         // length
        PROT_READ | PROT_WRITE | PROT_EXEC, // prot
        MAP_ANONYMOUS | MAP_PRIVATE,        // flags
        static_cast<uint64_t>(-1),          // fd
        0);                                 // offset

    if (remote_mem == 0 || remote_mem == static_cast<uint64_t>(-1)) {
        fprintf(stderr, "remote mmap failed: returned %p\n", (void*)remote_mem);
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return 1;
    }
    printf("[+] remote memory at %p\n", (void*)remote_mem);

    // write .so path to remote memory
    if (!poke_data(pid, remote_mem, so_path, path_len)) {
        fprintf(stderr, "failed to write path to remote memory\n");
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return 1;
    }
    printf("[*] wrote path: %s\n", so_path);

    // call dlopen(path, RTLD_NOW)
    printf("[*] calling dlopen...\n");
    uint64_t handle = remote_call(pid, r_dlopen, remote_mem, RTLD_NOW);

    if (handle == 0) {
        fprintf(stderr, "[-] dlopen returned NULL (load failed)\n");
        // try to get dlerror - resolve remote dlerror
        uintptr_t r_dlerror = remote_func(pid, "libdl.so", reinterpret_cast<void*>(&dlerror));
        if (r_dlerror) {
            uint64_t err_ptr = remote_call(pid, r_dlerror);
            if (err_ptr) {
                // read error string from remote
                char errbuf[256]{};
                for (size_t i = 0; i < sizeof(errbuf) - 8; i += 8) {
                    long word = ptrace(PTRACE_PEEKDATA, pid, (void*)(err_ptr + i), nullptr);
                    memcpy(errbuf + i, &word, 8);
                    if (memchr(&word, 0, 8)) break;
                }
                errbuf[sizeof(errbuf) - 1] = 0;
                fprintf(stderr, "    dlerror: %s\n", errbuf);
            }
        }
    } else {
        printf("[+] dlopen succeeded, handle=%p\n", (void*)handle);
    }

    printf("[*] detaching\n");
    ptrace(PTRACE_DETACH, pid, nullptr, nullptr);

    return handle ? 0 : 1;
}
