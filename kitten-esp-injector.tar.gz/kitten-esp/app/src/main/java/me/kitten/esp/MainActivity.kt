package me.kitten.esp

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader

class MainActivity : Activity() {

    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var injectBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private val targetPkg = "com.axlebolt.standoff2"
    private val tmpDir = "/data/local/tmp"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
            setBackgroundColor(0xFF0D0D10.toInt())
        }

        val title = TextView(this).apply {
            text = "kitten esp"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }

        statusView = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF888888.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 24)
        }

        injectBtn = Button(this).apply {
            text = "INJECT"
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF1A1A2E.toInt())
            setPadding(32, 24, 32, 24)
            setOnClickListener { doInject() }
        }

        logView = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFFAAAAAAu.toInt())
            typeface = Typeface.MONOSPACE
            setPadding(0, 24, 0, 0)
        }

        val scroll = ScrollView(this).apply {
            addView(logView)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        root.addView(title)
        root.addView(statusView)
        root.addView(injectBtn)
        root.addView(scroll)
        setContentView(root)

        refreshStatus()
    }

    private fun log(msg: String) {
        handler.post {
            logView.append("$msg\n")
        }
    }

    private fun refreshStatus() {
        val pid = findPid()
        statusView.text = if (pid > 0) {
            "standoff 2 running (pid $pid)"
        } else {
            "standoff 2 not running"
        }
        injectBtn.isEnabled = pid > 0
    }

    private fun findPid(): Int {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "pidof $targetPkg"))
            val output = proc.inputStream.bufferedReader().readText().trim()
            proc.waitFor()
            // pidof may return multiple pids, take first
            output.split("\\s+".toRegex()).firstOrNull()?.toIntOrNull() ?: -1
        } catch (e: Exception) {
            -1
        }
    }

    private fun suExec(vararg cmd: String): Pair<Int, String> {
        val full = cmd.joinToString(" ")
        val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", full))
        val stdout = proc.inputStream.bufferedReader().readText()
        val stderr = proc.errorStream.bufferedReader().readText()
        val code = proc.waitFor()
        return code to (stdout + stderr).trim()
    }

    private fun copyAsset(name: String, dst: File) {
        val src = File(applicationInfo.nativeLibraryDir, name)
        if (!src.exists()) {
            throw Exception("$name not found in ${applicationInfo.nativeLibraryDir}")
        }
        // copy via su to bypass permission issues
        val (code, out) = suExec("cp", src.absolutePath, dst.absolutePath)
        if (code != 0) throw Exception("cp failed: $out")
    }

    private fun doInject() {
        injectBtn.isEnabled = false
        logView.text = ""

        Thread {
            try {
                val pid = findPid()
                if (pid <= 0) {
                    log("[-] standoff 2 is not running")
                    return@Thread
                }
                log("[*] target pid: $pid")

                // copy .so
                val soFile = File("$tmpDir/liblemmingrmt.so")
                log("[*] copying liblemmingrmt.so...")
                copyAsset("liblemmingrmt.so", soFile)
                suExec("chmod", "644", soFile.absolutePath)
                log("[+] ${soFile.absolutePath}")

                // copy injector
                val injFile = File("$tmpDir/kitten_injector")
                log("[*] copying injector...")
                copyAsset("injector", injFile)
                suExec("chmod", "755", injFile.absolutePath)
                log("[+] ${injFile.absolutePath}")

                // run injector
                log("[*] injecting into pid $pid...")
                val (code, output) = suExec(
                    injFile.absolutePath, pid.toString(), soFile.absolutePath
                )
                for (line in output.lines()) {
                    if (line.isNotBlank()) log(line)
                }

                if (code == 0) {
                    log("\n[+] injection successful")
                } else {
                    log("\n[-] injection failed (exit $code)")
                    log("[?] try: su -c setenforce 0")
                }
            } catch (e: Exception) {
                log("[-] error: ${e.message}")
            } finally {
                handler.post {
                    injectBtn.isEnabled = true
                    refreshStatus()
                }
            }
        }.start()
    }
}
