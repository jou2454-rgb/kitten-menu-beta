android studio -> open папку KittenMenu -> дождаться gradle sync -> Build > Build APK(s)
apk: app/build/outputs/apk/debug/app-debug.apk
первый load попросит разрешение "поверх других приложений"
unload: кнопка в приложении или в шторке уведомлений
рут не нужен
