plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "me.kitten.menu"
    compileSdk = 34
    defaultConfig {
        applicationId = "me.kitten.menu"
        minSdk = 26
        targetSdk = 33 // 33 чтобы не требовать foregroundServiceType на Android 14
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
