package me.kitten.menu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.webkit.WebView

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var web: WebView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "unload") { stopSelf(); return START_NOT_STICKY }
        if (web == null) { startForeground(1, notification()); show() }
        return START_NOT_STICKY
    }

    private fun show() {
        val dm = resources.displayMetrics
        val v = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            setBackgroundColor(Color.TRANSPARENT)
            loadUrl("file:///android_asset/menu.html?overlay=1")
        }
        val p = WindowManager.LayoutParams(
            (dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.7).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (dm.heightPixels * 0.08).toInt() }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm!!.addView(v, p)
        web = v
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "menu", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("unload"), PendingIntent.FLAG_IMMUTABLE
        )
        val act = Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_delete), "unload", pi).build()
        return Notification.Builder(this, "ov")
            .setContentTitle("kitten.me loaded")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(act)
            .build()
    }

    override fun onDestroy() {
        web?.let { wm?.removeView(it); it.destroy() }
        web = null
        super.onDestroy()
    }
}
